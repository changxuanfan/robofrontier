"""Offline asset contracts; no agents, dispatcher or action server."""
from collections import Counter
import copy
import json
import unittest

import mujoco
import numpy as np

from robofrontier.cube_transport import ROOT, layout, make_task, replay_reference, route


class CubeTransportTests(unittest.TestCase):
    def test_inventory_and_topology_all_sizes(self):
        for n in range(3, 13):
            env = layout(n)
            self.assertEqual(len(env['stations']), n)
            self.assertEqual(len(env['objects']), 3*n)
            self.assertEqual(set(Counter(o['source'] for o in env['objects']).values()), {3})
            self.assertEqual(len(env['edges']), n if n > 3 else n-1)
            adjacency = {frozenset(e['stations']) for e in env['edges']}
            for a in env['stations']:
                for b in env['stations']:
                    r = route(a['id'], b['id'], n, env['topology'])
                    self.assertEqual((r[0], r[-1]), (a['id'], b['id']))
                    self.assertEqual(len(r), len(set(r)))
                    self.assertTrue(all(frozenset(pair) in adjacency for pair in zip(r, r[1:])))

    def test_saved_tasks_and_schedules_all_sizes_and_seeds(self):
        for n in range(3, 13):
            env = layout(n)
            for seed in (0, 1, 2):
                task = json.loads((ROOT/f"configs/tasks/cube_transport/{env['id']}/seed-{seed}.json").read_text())
                self.assertTrue(all(len(orders) == 3 for orders in task['orders'].values()))
                assigned = [o['object_id'] for orders in task['orders'].values() for o in orders]
                self.assertCountEqual(assigned, [o['id'] for o in env['objects']])
                result = json.loads((ROOT/f"benchmarks/cube_transport/references/{task['id']}.json").read_text())
                replay_reference(env, task, result)
                self.assertLessEqual(result['lower_bound_phase_slots_for_fixed_routes'], result['parallel_feasible_phase_slots'])
                self.assertLess(result['parallel_feasible_phase_slots'], result['serial_phase_slots'])
                self.assertEqual(result['optimality_proven'], result['lower_bound_phase_slots_for_fixed_routes'] == result['parallel_feasible_phase_slots'])

    def test_seed_reproducibility(self):
        env = layout(8)
        self.assertEqual(make_task(env, 2), make_task(env, 2))
        self.assertNotEqual(make_task(env, 1)['orders'], make_task(env, 2)['orders'])

    def test_schedule_replay_rejects_double_booking(self):
        env = layout(4)
        task = json.loads((ROOT/'configs/tasks/cube_transport/ring-04/seed-0.json').read_text())
        result = json.loads((ROOT/'benchmarks/cube_transport/references/ring-04-seed0.json').read_text())
        broken = copy.deepcopy(result)
        broken['schedule'][0].append(copy.deepcopy(broken['schedule'][0][0]))
        with self.assertRaises(AssertionError):
            replay_reference(env, task, broken)

    def test_loadable_reset_keyframe_at_both_scale_endpoints(self):
        for n in (3, 12):
            env = layout(n)
            model = mujoco.MjModel.from_xml_path(str(ROOT/f"configs/environments/cube_transport/{env['id']}/scene.xml"))
            self.assertEqual(model.nu, 8*n)
            self.assertEqual(model.nq, 9*n+7*3*n)
            data = mujoco.MjData(model)
            mujoco.mj_resetDataKeyframe(model, data, model.key('initial').id)
            mujoco.mj_forward(model, data)
            for station in env['stations']:
                np.testing.assert_allclose(data.site(station['id']+'_tcp').xpos, station['home_tcp_m'], atol=.002)
            for obj in env['objects']:
                np.testing.assert_allclose(data.body(obj['id']).xpos, obj['initial_position_m'], atol=1e-9)


if __name__ == '__main__':
    unittest.main()
